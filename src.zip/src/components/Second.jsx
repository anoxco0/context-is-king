
export const Second = ()=>{

    return (
        <div className="box">
            <input type="text" name="" id="state_of_residence"  />
            <input type="text" name="" id="address" />
            <input type="text" name="" id="pin_code" />
            <button>Submit</button>
        </div>
    )
}
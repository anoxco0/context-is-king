import { useNavigate } from "react-router-dom"



export const First = ()=>{
    const navigate= useNavigate();
    const btnHandle=()=>{
        navigate('/registration/two')
    }
    return (
        <div className="box">
            <label htmlFor="">Full Name</label>
            <input type="text" name="" id="name" placeholder="Your Full Name" />
            <label htmlFor="">Age</label>
            <input type="text" name="" id="age" placeholder="Your Age"/>
            <label htmlFor="">Date of Birth</label>
            <input type="date" name="" id="date_of_birth" />
            <button className="btn" onClick={()=>{btnHandle()}}>next</button>
        </div>
    )
}